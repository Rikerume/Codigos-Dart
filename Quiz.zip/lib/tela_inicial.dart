import 'package:flutter/material.dart';
import 'tela_quiz.dart';

class Tela_Inicial extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Quiz App')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/01_Lillia-Splash-Base.jpg',
            ),
            SizedBox(height: 20),
            Text(
              'Bem Vindo ao Quiz',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TelaQuizz()),
                );
              },
              child: Text('Iniciar Quiz'),
            ),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

// class TelaQuizz extends StatefulWidget {
//   @override
//   _QuizScreenState createState() => _QuizScreenState();
// }

// class _QuizScreenState extends State<TelaQuizz> {
//   int _questionIndex = 0;
//   int _totalScore = 0;

//   void _answerQuestion(int score) {
//     setState(() {
//       _totalScore += score;
//       _questionIndex++;
//     });
//   }

//   void _resetQuiz() {
//     setState(() {
//       _questionIndex = 0;
//       _totalScore = 0;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (_questionIndex >= _questions.length) {
//       return Result(_totalScore,
//           _resetQuiz); // Passa o método _resetQuiz para a classe Result
//     } else {
//       return Quiz(
//         questionIndex: _questionIndex,
//         answerQuestion: _answerQuestion,
//         questions: _questions,
//       );
//     }
//   }

//   final List<Map<String, Object>> _questions = [
//     {
//       'questionText': 'Quem é Lain?',
//       'answers': [
//         {'text': 'Lain é Lain', 'score': 1},
//         {'text': 'Lain não existe', 'score': 0},
//         {'text': 'Lain somos nós', 'score': 0}
//       ],
//     },
//     {
//       'questionText': 'Qual o nome do bola de canhão?',
//       'answers': [
//         {'text': 'Bala de canhão', 'score': 1},
//         {'text': 'Bola de canhão', 'score': 0},
//         {'text': 'Sla bola, n sei', 'score': 0}
//       ],
//     },
//     {
//       'questionText': 'Qual o valor da proporção áurea?',
//       'answers': [
//         {'text': '3,1416', 'score': 0},
//         {'text': '6.287409', 'score': 0},
//         {'text': '1.618034', 'score': 1}
//       ],
//     }
//   ];
// }

// class Quiz extends StatelessWidget {
//   final int questionIndex;
//   final Function(int) answerQuestion;
//   final List<Map<String, Object>> questions;

//   Quiz({
//     required this.questionIndex,
//     required this.answerQuestion,
//     required this.questions,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         Question(questions[questionIndex]['questionText'] as String),
//         ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
//             .map(
//               (answer) => Answer(
//                 answer['text'] as String,
//                 () => answerQuestion(answer['score'] as int),
//               ),
//             )
//             .toList(),
//       ],
//     );
//   }
// }

// class Question extends StatelessWidget {
//   final String questionText;

//   Question(this.questionText);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: EdgeInsets.all(10),
//       child: Padding(
//         padding: EdgeInsets.all(10), // Adiciona um espaçamento interno
//         child: Text(
//           questionText,
//           style: TextStyle(
//             fontSize: 18,
//             color: Colors.black, // Altera a cor do texto para preto
//           ),
//           textAlign: TextAlign.center,
//         ),
//       ),
//     );
//   }
// }

// class Answer extends StatelessWidget {
//   final String answerText;
//   final Function selectHandler;

//   Answer(this.answerText, this.selectHandler);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: double.infinity,
//       margin: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//       child: ElevatedButton(
//         onPressed: () => selectHandler(),
//         child: Text(answerText),
//       ),
//     );
//   }
// }

class Result extends StatelessWidget {
  final int totalScore;
  final Function resetQuiz;

  Result(this.totalScore, this.resetQuiz);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Your total score is $totalScore',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => resetQuiz(),
            child: Text('Voltar ao Inicio'),
          ),
        ],
      ),
    );
  }
}
