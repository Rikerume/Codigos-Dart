import 'package:flutter/material.dart';
import 'tela_inicial.dart';

//import 'package:flutter/material.dart';

// void main() {
//   runApp(MinhaApp());
// }

// class MinhaApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Minha Primeira App'),
//         ),
//         body: Center(
//           child: Image.asset(
//             'assets/images/01_Lillia-Splash-Base.jpg',
//           ),
//         ),
//       ),
//     );
//   }
// }

void main() {
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meu App de Quiz',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Tela_Inicial(),
    );
  }
}
